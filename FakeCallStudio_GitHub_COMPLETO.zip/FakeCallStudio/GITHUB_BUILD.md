# FakeCall Studio — compilar APK en GitHub

Este paquete incluye el código fuente Android y el flujo de GitHub Actions para compilar un APK de depuración.

## Subirlo desde Android
1. Extrae este ZIP.
2. Abre la carpeta `FakeCallStudio` que contiene `app`, `build.gradle.kts` y `settings.gradle.kts`.
3. En GitHub crea un repositorio vacío.
4. Sube el CONTENIDO de esa carpeta a la raíz del repositorio, incluida la carpeta `.github`.
5. Abre la pestaña Actions y ejecuta `Compilar APK Android` si no empieza automáticamente.
6. Cuando termine correctamente, abre la ejecución y descarga el artefacto `FakeCallStudio-APK`.
7. Extrae el artefacto y prueba `app-debug.apk`.

El APK aún no está compilado; GitHub debe ejecutar el flujo. Es un APK de depuración para pruebas, no una versión firmada para Play Store.
